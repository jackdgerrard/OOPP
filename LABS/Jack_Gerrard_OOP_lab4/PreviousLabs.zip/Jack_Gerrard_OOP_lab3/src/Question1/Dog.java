package Question1;

public class Dog {
	

	public void bark(){
		System.out.println("AWOOF");
	}
}
