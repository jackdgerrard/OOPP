package lab1_question1_a;

public class sing {

}
