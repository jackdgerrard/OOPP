public class testPerson {

	public static void main(String[] args) {
		Person P = new Person ("Samsung","Jack", 8 );
		P.print();

	}

}
